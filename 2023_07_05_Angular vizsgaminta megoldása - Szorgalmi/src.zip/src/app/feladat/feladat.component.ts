import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrls: ['./feladat.component.css']
})
export class FeladatComponent {
  szam!: number;
  megoldas: string[] = [];


  primVizsgalo(number: number): string {
    if (number <= 1) {
      return "NEM prím";
    }

    for (let i = 2; i <= Math.sqrt(number); i++) {
      if (number % i === 0) {
        return "NEM prím";
      }
    }

    return "prím";
  }

  EredmenyMentes(): void {
    const eredmeny = this.primVizsgalo(this.szam);
    this.megoldas.push(`A(z) ${this.szam} : ${eredmeny}`);
  }
}
